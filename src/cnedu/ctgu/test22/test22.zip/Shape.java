package cnedu.ctgu.test22;

/**
 * @author LeiJian
 * @date 2019/10/31 10:59
 */
public class Shape {
    public double getArea() {
        return 0;
    }
}

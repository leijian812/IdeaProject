package cnedu.ctgu.test23;

/**
 * @author LeiJian
 * @date 2019/10/31 10:59
 */
public abstract class Shape {
    public abstract double getArea();
}
